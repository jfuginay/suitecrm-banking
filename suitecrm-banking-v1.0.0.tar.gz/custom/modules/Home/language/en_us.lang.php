<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$mod_strings = array(
    'LBL_REAL_ESTATE_TITLE' => 'Real Estate & Payment Processing',
    'LBL_REAL_ESTATE_DESCRIPTION' => 'Manage real estate clients with integrated credit card processing and COBOL banking features.',
);
?>